import createContext from 'create-react-context';

const LiveContext = createContext({});

export default LiveContext;
